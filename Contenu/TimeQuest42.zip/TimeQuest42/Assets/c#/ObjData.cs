using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "obj", menuName = "MyGame/obj")]
public class ObjData : ScriptableObject
{
    public int GainOr;
    public int GainVie;
}
