using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Soldat : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector2 coordinates;
    public bool moove;
    public static float x;
    public static float y;
    public int deplace;
    public bool bateau;
   
    void Start(){
        this.deplace = 3;
        this.moove = true;
        this.bateau = false;
        x = this.gameObject.transform.position.x;
        y = this.gameObject.transform.position.y;
    }

  
    // Update is called once per frame
    void OnMouseDown(){
    
    Debug.Log(this.gameObject.name);
  
    
         GameObject request = (GameObject) Instantiate((GameObject) Resources.Load("perso/action"));
         this.deplace = 3;
         request.name = "request";
         request.transform.position = new Vector3(-10,12,0);
         this.moove = false;
    }
}
