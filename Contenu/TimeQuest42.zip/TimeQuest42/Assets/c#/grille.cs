using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class grille : MonoBehaviour
{
    // Start is called before the first frame update
   
    public GameObject soldat;
    public GameObject gri;
    public GameObject car;
    public GameObject coc;
    public GameObject our;
    public GameObject chev;
    public GameObject bar;


    void Start() 
    {
       //impression de la map
        GameObject tileobj = (GameObject) Instantiate(gri);
        tileobj.name = "map";
        tileobj.transform.position = new Vector3(12,12,0);
        

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
