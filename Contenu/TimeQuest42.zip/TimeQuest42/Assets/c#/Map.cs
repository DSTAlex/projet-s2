﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public class Map : MonoBehaviour
    {
        public int X;
        public int Y;
        public bool IsPresent;
        public char type;

        public Map(int x, int y, char c)
        {
            X = x;
            Y = y;
            IsPresent = false;
            type = c;
        }
    }
