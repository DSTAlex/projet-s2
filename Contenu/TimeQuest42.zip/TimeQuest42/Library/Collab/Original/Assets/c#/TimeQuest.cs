using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeQuest : MonoBehaviour
{
    // Start is called before the first frame update
    public grille grille;
    public Carotte[] carottes;
    public List<Soldat> soldats1;
    public List<Soldat> soldats2;
    public  Coca[] coca;
    public Barbare[] barbars;
    public List<Aiscript> ailist;
    public Ours[] ours;
    public Cheval[] chevaux;
    public static bool TurnEquip1;
    public static bool TurnEquip2;
    public int Turn;

    void Start()
    {
        Turn = 0;
        TurnEquip1 = true;
        TurnEquip2 = false;

        GameObject boardObject = new GameObject("Board");
        grille= boardObject.AddComponent<grille>();
        grille.gri = (GameObject) Resources.Load("perso/Grid");
        //objets
        //carottes
        carottes = new Carotte[2];
        GameObject carotte1 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Carotte"));
        GameObject carotte2 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Carotte"));
        carottes[1] = carotte1.AddComponent<Carotte>();
        carottes[0] = carotte2.AddComponent<Carotte>();
        carottes[1].transform.position = new Vector3(12, 5, 0);
        carottes[0].transform.position = new Vector3(12, 19, 0);
        //coca
        coca= new Coca[2];
        GameObject coca1 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Coca"));
        GameObject coca2 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Coca"));
        coca[1] = coca1.AddComponent<Coca>();
        coca[0] = coca2.AddComponent<Coca>();
        coca[1].transform.position = new Vector3(12, 9, 0);
        coca[0].transform.position = new Vector3(12, 15, 0);
        //chevaux
        chevaux= new Cheval[3];
        GameObject chev1 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Cheval"));
        GameObject chev2 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Cheval"));
        GameObject chev3 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Cheval"));
        chevaux[1] = chev1.AddComponent<Cheval>();
        chevaux[0] = chev2.AddComponent<Cheval>();
        chevaux[2] = chev3.AddComponent<Cheval>();
        chevaux[1].transform.position = new Vector3(3, 12, 0);
        chevaux[0].transform.position = new Vector3(18, 8, 0);
        chevaux[2].transform.position = new Vector3(18, 16, 0);
        //personnages
        //soldats
        //equipe1
        soldats1 = new List<Soldat>();
        GameObject soldat1= (GameObject)Instantiate((GameObject)Resources.Load("perso/Soldatteam1"));
        soldat1.transform.position = new Vector3(12,2,0);
        soldats1.Add(soldat1.AddComponent<Soldat>());
        //equipe2
        soldats2=new List<Soldat>();
        GameObject soldat2v = (GameObject) Instantiate((GameObject) Resources.Load("perso/Soldatteam2"));
        soldat2v.transform.position = new Vector3(12,22,0);
        soldats2.Add(soldat2v.AddComponent<Soldat>());
        //intelligences artificielles
        //barbares
        barbars= new Barbare[3];
        GameObject bar1 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Barbare"));
        GameObject bar2 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Barbare"));
        GameObject bar3 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Barbare"));
        barbars[1] = bar1.AddComponent<Barbare>();
        barbars[0] = bar2.AddComponent<Barbare>();
        barbars[2] = bar3.AddComponent<Barbare>();
        barbars[1].transform.position = new Vector3(8, 12, 0);
        barbars[0].transform.position = new Vector3(12, 12, 0);
        barbars[2].transform.position = new Vector3(16, 12, 0);
        //ours
        ours= new Ours[4];
        GameObject ours1 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Ours"));
        GameObject ours2 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Ours"));
        GameObject ours3 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Ours"));
        GameObject ours4 = (GameObject) Instantiate((GameObject) Resources.Load("perso/Ours"));
        ours[1] = ours1.AddComponent<Ours>();
        ours[0] = ours2.AddComponent<Ours>();
        ours[2] = ours3.AddComponent<Ours>();
        ours[3] = ours4.AddComponent<Ours>();
        ours[1].transform.position = new Vector3(2, 6, 0);
        ours[0].transform.position = new Vector3(2, 18, 0);
        ours[2].transform.position = new Vector3(16, 4, 0);
        ours[3].transform.position = new Vector3(16, 21, 0);
    }
  public static void FinTurn()
    {
       TurnEquip1 = false;
       TurnEquip2 = false;
    }

     public static void SpawnObject()
    {

    }

     public static void TurnIA() { }
 public static bool Validsoldat(float x, float y)
    {
        bool res = false;
        if ((x <= 24 && y <= 24) && (x >= 1 && y >= 1))
        {
            res = true;
            if (x ==24 || y==24 || x==1 || y==1)
            {
                res = false;
            }
if(y<18 && y>5 && x==22)
{
res=false;
}
if(y>6 && y<17 && x==21)
{
res= false;
}
if(y>9 && y<14 && x==20)
{
res= false;
}
        }
        return res;
    }

    void Update()
    {
        while (Turn < 42)
        {
            while (!TurnEquip1)
            {
                Deplace(soldats1);
            }
            TurnEquip2 = true;
            while (!TurnEquip2)
            {
                Deplace(soldats2);
            }
            TurnIA();
            SpawnObject();
            Turn++;
            TurnEquip1 = true;
        }
        
    }

    public static void Deplace(List<Soldat> equip)
    {
//soldats equipe 1
        foreach (var soldat in equip)
            {
              if(soldat.moove ==false)
              {
                if(Input.GetKeyDown(KeyCode.UpArrow))
                 {
                 
                  if(Validsoldat(soldat.transform.position.x,soldat.transform.position.y+1))
                   {
  Debug.Log("bougehaut");
                   soldat.transform.position = new Vector3(soldat.transform.position.x, soldat.transform.position.y+1,0);
                     soldat.deplace--;
                   }
                  }
                 else if(Input.GetKeyDown(KeyCode.LeftArrow))
                 {
                  if(Validsoldat(soldat.transform.position.x-1,soldat.transform.position.y))
                   {
  Debug.Log("bougehaut");
                   soldat.transform.position = new Vector3(soldat.transform.position.x-1, soldat.transform.position.y,0);
                     soldat.deplace--;
                   }
                  }
 else if(Input.GetKeyDown(KeyCode.DownArrow))
                 {
                  if(Validsoldat(soldat.transform.position.x,soldat.transform.position.y-1))
                   {
  Debug.Log("bougehaut");
                   soldat.transform.position = new Vector3(soldat.transform.position.x, soldat.transform.position.y-1,0);
                     soldat.deplace--;
                   }
                  }
                 else if(Input.GetKeyDown(KeyCode.RightArrow))
                 {
                  if(Validsoldat(soldat.transform.position.x+1,soldat.transform.position.y))
                   {
  Debug.Log("bougehaut");
                   soldat.transform.position = new Vector3(soldat.transform.position.x+1, soldat.transform.position.y,0);
                     soldat.deplace--;
                   }
                      }
                    else
                    {
                      
//mettre un message d'erreur : Vous ne pouvez pas aller lÃ 
                   }
                 
                  if(soldat.deplace ==0)
                  {
                    soldat.moove=true;
                  }
               }
}
    
 }
}
