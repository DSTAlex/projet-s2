using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fintour : MonoBehaviour
{
    // Start is called before the first frame update
    public bool moove;
    void Start()
    {
        this.moove = false;
    }

    // Update is called once per frame
    void OnMouseDown(){
    
        Debug.Log(this.gameObject.name);
        this.moove = true; 
    }
}
