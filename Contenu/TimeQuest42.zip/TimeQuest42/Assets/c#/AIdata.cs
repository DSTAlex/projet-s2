using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="AI", menuName="MyGame/AI")]
public class AIdata: ScriptableObject
{
    public int Attaque;
    public int Vie;
    public int Attend;
    public int vue;
    public int deplace;
    public int dropor;
}
