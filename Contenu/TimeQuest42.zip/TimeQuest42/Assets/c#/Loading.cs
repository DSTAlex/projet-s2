using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Loading : MonoBehaviour
{
    public Dropdown listsave;
    public GameObject Load;
    string[] malist;
    int x = 0;

    void Start()
    {
        listsave.ClearOptions();
        Load.SetActive(false);
    }

    
    public void load()
    {
        Load.SetActive(true);
        malist = Directory.GetFiles("Save/");
        List<string> option = new List<string>();
        for(int i=0; i < malist.Length; i++)
        {
            string opt = "";
            for(int j=5; j< malist[i].Length - 4; j++)
            {
                opt += malist[i][j];
            }
            option.Add(opt);
        }

        listsave.AddOptions(option);
    }

    public void confirm()
    {
        Debug.Log(malist[x]);
    }
    public void fct1(int a)
    {
        x = a;
    }
}
