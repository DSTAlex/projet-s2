using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class TimeQuest : MonoBehaviour
{
    // Start is called before the first frame update
    public grille grille;
    public int[] totalmoney = new int[2];
    public int[] totalbois = new int[2];
    public List<Caracterescript>[] Equip;
    public List<Caracterescript> EquipBleu;
    public List<Caracterescript> EquipRouge;
    public List<Objscript> objlist;
    public List<Aiscript> ailist;
    public Caracterescript PersoSelect;
    public static bool TurnEquip1;
    public static bool TurnEquip2;
    public int Turn;
    public Map[,] zonemap;
    public AIdata bar;
    public AIdata our;
    public ObjData car;
    public ObjData bat;
    public ObjData chev;
    public ObjData coc;
    public CaractereData sol;
    public CaractereData cav;
    public CaractereData roi;

    void Start()
    {
        Turn = 0;
        TurnEquip1 = true;
        TurnEquip2 = false;
        Equip = new List<Caracterescript>[2];
        EquipRouge = new List<Caracterescript>();
        EquipBleu = new List<Caracterescript>();
        Equip[1] = EquipBleu;
        Equip[0] = EquipRouge;
        PersoSelect = null;
        CreateMap();

        GameObject boardObject = new GameObject("Board");
        grille= boardObject.AddComponent<grille>();
        grille.gri = (GameObject) Resources.Load("perso/Grid");
        //objets
        //carottes
        CreateCarotte(12, 19);
        CreateCarotte(12, 5);
        //coca
        CreateCoca(12, 9);
        CreateCoca(12, 15);
        //chevaux
        
        CreateCheval(3, 12);
        CreateCheval(18, 8);
        CreateCheval(18, 16);
        //personnages
        //soldats
        //equipe1
        CreateSoldat(12, 2, 0);
        //equipe2
        CreateSoldat(12, 22, 1);
        //intelligences artificielles
        //barbares
        CreateBarbar(8, 12);
        CreateBarbar(12, 12);
        CreateBarbar(16, 12);

        //ours
        CreateOurs(2, 6);
        CreateOurs(2, 18);
        CreateOurs(16, 4);
        CreateOurs(16, 21);
        
    }

    public void CreateMap()
    {
        zonemap = new Map[24, 24];
        Map[,] map = new Map[24, 24];
        int i = 0;
        //Creation zones interdites
        while (i < 23)
        {
            map[i, 0] = new Map(i, 0, 'i');
            map[i, 23] = new Map(i, 23, 'i');
            map[0, i] = new Map(0, i, 'i');
            map[23, i] = new Map(23, i, 'i');
            i++;
        }
        map[1, 1] = new Map(1, 1, 'i');
        map[1, 22] = new Map(1, 22, 'i');
        map[0, 0] = new Map(0, 0, 'i');
        map[23, 23] = new Map(23, 23, 'i');
        map[23, 0] = new Map(23, 0, 'i');
        map[0, 23] = new Map(0, 23, 'i');
        //Creation zones de forets
        i = 3;
        int j = 1;
        while (j < 4)
        {
            int l = i;
            while (i < 23 - l)
            {
                map[j, i] = new Map(j, i, 'f');
                i++;
            }

            i = l + 1;
            j++;
        }
        map[4, 6] = new Map(4, 6, 'f');
        map[4, 11] = new Map(4, 11, 'f');
        map[4, 12] = new Map(4, 12, 'f');
        map[4, 17] = new Map(4, 17, 'f');

        map[8, 6] = new Map(8, 6, 'f');
        map[9, 6] = new Map(9, 6, 'f');
        map[8, 7] = new Map(8, 7, 'f');
        map[8, 23 - 6] = new Map(8, 23 - 6, 'f');
        map[9, 23 - 6] = new Map(9, 23 - 6, 'f');
        map[8, 23 - 7] = new Map(8, 23 - 7, 'f');

        map[13, 4] = new Map(13, 4, 'f') ;
        map[13, 23 - 4] = new Map(13, 23 - 4, 'f');
        i = 3;
        j = 14;
        while (j < 19)
        {
            if (j < 16)
            {
                i = 3;
                while (i < 6)
                {
                    map[j, i] = new Map(j, i, 'f');
                    map[j, 23 - i] = new Map(j, 23 - i, 'f');
                    i++;
                }
            }
            else
            {
                if (j == 16)
                {
                    i = 3;
                    while (i < 5)
                    {
                        map[j, i] = new Map(j, i, 'f');
                        map[j, 23 - i] = new Map(j, 23 - i, 'f');
                        i++;
                    }
                }
                else
                {
                    i = 2;
                    while (i < 4)
                    {
                        map[j, i] = new Map(j, i, 'f');
                        map[j, 23 - i] = new Map(j, 23 - i, 'f');
                        i++;
                    }
                }
            }
            j++;
        }

        map[21, 2] = new Map(21, 2, 'f');
        map[21, 23 - 2] = new Map(21, 23 - 2, 'f');

        i = 7;
        while (i < 9)
        {
            j = 17;
            while (j < 21)
            {
                map[j, i] = new Map(j, i, 'f');
                map[j, 23 - i] = new Map(j, 23 - i, 'f');
                j++;
            }
            i++;
        }
        //Creation zones de montagnes
        map[22, 1] = new Map(22, 1, 'm');
        map[22, 23 - 1] = new Map(22, 23 - 1, 'm');

        map[1, 2] = new Map(1, 2, 'm');
        map[1, 23 - 2] = new Map(1, 23 - 2, 'm');

        map[2, 1] = new Map(2, 1, 'm');
        map[2, 23 - 1] = new Map(2, 23 - 1, 'm');

        j = 5;
        i = 10;
        while (i < 14)
        {
            j = 5;
            while (j < 19)
            {
                map[j, i] = new Map(j, i, 'm');
                j++;
            }
            i++;
        }

        map[4, 10] = new Map(4, 10, 'm');
        map[4, 23 - 10] = new Map(4, 23 - 10, 'm');
        //Creation zones de sables
        i = 1;
        j = 3;
        while (j < 23 - 3)
        {
            map[j, i] = new Map(j, i, 'd');
            map[j, 23 - i] = new Map(j, 23 - i, 'd');
            j++;
        }
        i = 2;
        j = 6;
        while (j < 17)
        {
            map[j, i] = new Map(j, i, 'd');
            map[j, 23 - i] = new Map(j, 23 - i, 'd');
            j++;
        }
        i = 3;
        j = 8;
        while (j < 14)
        {
            map[j, i] = new Map(j, i, 'd');
            map[j, 23 - i] = new Map(j, 23 - i, 'd');
            j++;
        }

        i = 4;
        j = 22;
        while (i < 8 && j > 19)
        {
            map[j, i] = new Map(j, i, 'd');
            map[j, 23 - i] = new Map(j, 23 - i, 'd');
            j--;
            i++;
        }
        i = 9;
        j = 19;
        while (i < 15)
        {
            map[j, i] = new Map(j, i, 'd');
            i++;
        }
        map[18, 9] = new Map(18, 9, 'd');
        map[18, 23 - 9] = new Map(18, 23 - 9, 'd');
        //Creation zone du lac
        i = 5;
        j = 22;
        while (j > 20)
        {
            int a = i;
            while (i < 23 - a)
            {
                map[j, i] = new Map(j, i, 'l');
                i++;
            }
            i = a + 1;
            j--;
        }
        i = 9;
        j = 20;
        while (i < 15)
        {
            map[j, i] = new Map(j, i, 'l');
            i++;
        }
        map[21, 17] = new Map(21, 17, 'l');
        map[22, 18] = new Map(22, 18, 'l');
        //Creation zones de prairies
        i = 0;
        while (i < 23)
        {
            j = 0;
            while (j < 23)
            {
                if (map[j, i] == null)
                    map[j, i] = new Map(j, i, 'p');
                j++;
            }
            i++;
        }
        int acestdrole = 0;
        while (acestdrole < 24)
        {
            int c = 0;
            while (c < 24)
            {
                zonemap[acestdrole, c] = map[c, acestdrole];
                c = c + 1;
            }
            acestdrole++;
        }
    }

    public void CreateBarbar( int x, int y)
    {
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/barbarian"));
        Aiscript barbarian1 = barbar1.AddComponent<Aiscript>();
        ailist.Add(barbarian1);
        barbarian1.jeu = this;
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.ai = bar;
        barbarian1.X = x;
        barbarian1.Y = y;
    }

    public void CreateOurs(int x, int y)
    {
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/oursian"));
        Aiscript barbarian1 = barbar1.AddComponent<Aiscript>();
        ailist.Add(barbarian1);
        barbarian1.jeu = this;
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.ai = our;
        barbarian1.X = x;
        barbarian1.Y = y;
    }

    public void CreateCarotte(int x, int y)
    {
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/carottee"));
        Objscript barbarian1 = barbar1.AddComponent<Objscript>();
        objlist.Add(barbarian1);
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.data = car;
        barbarian1.X = x;
        barbarian1.Y = y;
    }
    public void CreateCoca(int x, int y)
    {
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/cocae"));
        Objscript barbarian1 = barbar1.AddComponent<Objscript>();
        objlist.Add(barbarian1);
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.data = coc;
        barbarian1.X = x;
        barbarian1.Y = y;
    }
    public void CreateCheval(int x, int y)
    {
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/chevall"));
        Objscript barbarian1 = barbar1.AddComponent<Objscript>();
        objlist.Add(barbarian1);
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.data = chev;
        barbarian1.X = x;
        barbarian1.Y = y;
    }
    public void CreateBateau(int x, int y)
    {
        throw new NotImplementedException();
        /*
        GameObject barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/bateau"));
        Objscript barbarian1 = barbar1.AddComponent<Objscript>();
        objlist.Add(barbarian1);
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.data = car;
        barbarian1.X = x;
        barbarian1.Y = y;
        */
    }

    public void CreateSoldat(int x, int y, int Team)
    {
        GameObject barbar1;
        if (Team==0)
            barbar1 = (GameObject)Instantiate((GameObject)Resources.Load("perso/SoldatRouge"));
        else
             barbar1= (GameObject)Instantiate((GameObject)Resources.Load("perso/SoldatBleu"));
        Caracterescript barbarian1 = barbar1.AddComponent<Caracterescript>();
        Equip[Team].Add(barbarian1);
        barbarian1.jeu = this;
        barbarian1.transform.position = new Vector2(x, y);
        barbarian1.data = sol;
        barbarian1.X = x;
        barbarian1.Y = y;
        barbarian1.Team = Team;
    }


    
    void Update()
    {
        if (Turn < 42)
        {
            if (TurnEquip1)
            {
                EquipRouge[0].Moove();
            }

            if (TurnEquip2)
            {
                EquipBleu[0].Moove();
            }
        }
        

    }

    
    public void Fintour()
    {
        if (TurnEquip1)
        {
            TurnEquip1 = false;
            TurnEquip2 = true;
            ResetMove(Equip[0]);
        }
        else if (TurnEquip2)
        {
            TurnEquip2 = false;
            ResetMove(Equip[1]);
            touria();
            //SpawnObject();
            Turn++;
            TurnEquip1 = true;
        } 
    }
    public void touria()
    {
        foreach(Aiscript ai in ailist)
        {
            Debug.Log("hey");
        }
    }
    public void SpawnObject()
    {
        throw new NotImplementedException();
    }
    public void ResetMove(List<Caracterescript> equip)
    {
        foreach(Caracterescript cara in equip)
        {
            cara.Deplace = 3;
        }
    }

    
    

}
