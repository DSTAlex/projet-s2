using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Objscript : MonoBehaviour
{
    public ObjData data;

    public Caracterescript istaken;
    public int X;
    public int Y;
    public int GainOr;
    public int GainVie;


    void Start()
    {
        this.GainOr = data.GainOr;
        this.GainVie = data.GainVie;
        istaken = null;
    }

    void Update()
    {
        
    }
}
