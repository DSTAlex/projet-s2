using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Caracterescript : MonoBehaviour
{
    public CaractereData data;
    public TimeQuest jeu;

    public List<Objscript> istaken;
    public int X;
    public int Y;
    public int Team;
    public int Vie;
    public int Prix;
    public int MeurtOr;
    public int MeurtBois;
    public int Force;
    public int Deplace;
    // Start is called before the first frame update
    void Start()
    {
        istaken = new List<Objscript>();
        Vie = data.Vie;
        Prix = data.Prix;
        MeurtOr = data.MeurtOr;
        MeurtBois = data.MeurtBois;
        Force = data.Force;

        Deplace = data.Deplace; ;
    }

    public bool Validsoldat(int x, int y)
    {
        bool boat = false;
        foreach (Objscript obj in istaken)
        {
            if (obj.GainVie == 0 && obj.GainOr == 0)
                boat = true;
        }
        bool res = true;
        for (int i = 0; i <= 1; i++)
        {
            foreach (Caracterescript cara in jeu.Equip[i])
            {
                if (cara.X == X && cara.Y == Y)
                {
                res = false;
                }
            }
        }
        
        foreach(Aiscript ai in jeu.ailist)
        {
            if (ai.X == X && ai.Y == Y)
            {
                res = false;
            }
        }

        if ((x <= 24 && y <= 24) && (x >= 0 && y >= 0))
        {
            
            if (jeu.zonemap[x, y].type =='i')
            {
                res = false;
            }
            else if (jeu.zonemap[x, y].type == 'l' && !boat)
            {
                res = false;
            }
            if (jeu.zonemap[x, y].IsPresent == true)
            {
                res = false;
            }
        }
        return res;

    }

    public void aaa()
    {
        if (Input.GetKey(KeyCode.UpArrow))
        {
            print("up arrow key is held down");
        }

        if (Input.GetKey(KeyCode.DownArrow))
        {
            print("down arrow key is held down");
        }
    }

    public void Moove()
    {
        
        if (Deplace > 0)
        {
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                
                if (true)//(Validsoldat(X, Y+1))
                {
                    Debug.Log("bougehaut");
                    Y += 1;
                    Deplace--;
                    transform.position = new Vector2(X, Y);
                }
            }
            else if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                if (true)//(Validsoldat(X-1, Y))
                {
                    Debug.Log("bougehaut");
                    X -= 1;
                    Deplace--;
                    transform.position = new Vector2(X, Y);
                }
            }
            else if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                if (true)//(Validsoldat(X,Y-1))
                {
                    Debug.Log("bougehaut");
                    Y -= 1;
                    Deplace--;
                    transform.position = new Vector2(X, Y);
                }
            }
            else if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                if (true)//(Validsoldat(X+1,Y))
                {
                    Debug.Log("bougehaut");
                    X += 1;
                    Deplace--;
                    transform.position = new Vector2(X, Y);
                }
            }
            
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
