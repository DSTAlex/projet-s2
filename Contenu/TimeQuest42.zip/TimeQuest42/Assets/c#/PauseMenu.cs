using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class PauseMenu : MonoBehaviour
{
    public static bool gameIsPaused = false;

    public GameObject pauseMenuUI;
    public GameObject SaveMenu;
    public GameObject ecraseMenuUI;
    public GameObject EquipeMenuUI;

    public string filename = "";

    void Start()
    {
        SaveMenu.SetActive(false);
        ecraseMenuUI.SetActive(false);
        pauseMenuUI.SetActive(false);
        EquipeMenuUI.SetActive(true);
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            
            if (gameIsPaused)
            {
                Resume();
            }
            else
            {
                Paused();
            }
        }
    }
    void Paused()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0;
        gameIsPaused = true;
        EquipeMenuUI.SetActive(false);
    }

    public void Resume()
    {
        ecraseMenuUI.SetActive(false);
        SaveMenu.SetActive(false);
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1;
        gameIsPaused = false;
        EquipeMenuUI.SetActive(true);
    }

    public void LoadMainMenu()
    {
        DontDestroyOnLoadScene.instance.RemoveFromDontDestroyOnLoad();
        Resume();
        SceneManager.LoadScene("MainMenu");
    }

    public void AskSave()
    {
        SaveMenu.SetActive(true);
    }


    public void AskSave2()
    {
        if (File.Exists(filename))
        {
            ecraseMenuUI.SetActive(true);
        }
        else
        {
            Save();
        }
    }

    public void changename(string name)
    {
        filename = "Save/" + name + ".txt";
        Debug.Log(filename);
    }

    public void Save()
    {
        File.Create(filename);
        SaveMenu.SetActive(false);
        ecraseMenuUI.SetActive(false);
    }

    public void QuitSaveMenu()
    {
        SaveMenu.SetActive(false);
        ecraseMenuUI.SetActive(false);
    }
        
}
