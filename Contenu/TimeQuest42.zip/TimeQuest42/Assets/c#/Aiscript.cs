using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aiscript : MonoBehaviour
{
    public TimeQuest jeu;
    public AIdata ai;

    public int X;
    public int Y;
    public int Attaque;
    public int Vie;
    public int Attend;
    public int vue;
    public int deplace;
    public int dropor;

    void Start()
    {
        this.Attaque = ai.Attaque;
        this.Vie = ai.Vie;
        this.Attend = ai.Attend;
        this.vue = ai.vue;
        this.deplace = ai.deplace;
        this.dropor = ai.dropor;
    }
    public int mort()
    {
        int ordonne = 0;
        if (Vie <= 0)
        {
            jeu.ailist.Remove(this);
            ordonne = dropor;
        }
        return ordonne;
    }
    /*
    public void attaque(){}

    public int distance(Caracters cara)
    {
        int res;
        int a = X - cara.X;
        if (a < 0)
            res = -a;
        else
            res = a;
        a = Y - cara.Y;
        if (a < 0)
            res += -a;
        else
            res += a;
        return res;
    }

    public Caracters cible()
    {
        Caracters res = null;
        int dist = vue;
        int a;
        foreach (var cara in jeu.soldats)
        {
            if (!(cara.bateau))
            {
                a = distance(cara);
                if (dist > a)
                {
                    dist = a;
                    res = cara;
                }
            }
        }
        foreach (var cara in jeu.soldats)
        {
            if (!(cara.bateau))
            {
                a = distance(cara);
                if (dist > a)
                {
                    dist = a;
                    res = cara;
                }
            }
        }

        return res;
    }

    public bool validpos(float x , float y)
    {
        bool res = false;
        if ((x <= 24 && y <= 24) && (x >= 1 && y >= 1))
        {
            res = true;
            if (x == 24 || y == 24 || x == 1 || y == 1)
            {
                res = false;
            }
            if (y < 18 && y > 5 && x == 22)
            {
                res = false;
            }
            if (y > 6 && y < 17 && x == 21)
            {
                res = false;
            }
            if (y > 9 && y < 14 && x == 20)
            {
                res = false;
            }
            if (false)//chateau 1
            {
                res = false;
            }
            if (false)//chateau 2
            {
                res = false;
            }
        }
        return res;
    }

    public void depto(Caracters cara)
    {
        float distx = X - cara.X;
        if (distx < 0)
            distx = -distx;
        float rest = deplace - distx;
        float nx;
        float ny;
        if (rest >= 0)
        {
            nx = cara.X;
            if (Y - cara.Y > 0)
                ny = Y - rest;
            else
                ny = Y + rest;
        }
        else if (X - cara.X > 0)
        {
            nx = X - deplace;
            ny = Y;
        }
        else
        {
            nx = X + deplace;
            ny = Y;
        }

        if (distance(cara) == 0)
        {
            if (X != nx)
            {
                if (X < nx)
                    nx -= 1;
                else
                    nx += 1;
            }
            else
            {
                if (Y < ny)
                    ny -= 1;
                else
                    ny += 1;
            }
        }
        if (validpos(nx, ny))
        {
            X = nx;
            Y = ny;
            transform.position = new Vector3(X, Y, 0);
        }
        else
        {
            deplace -= 1;
            depto(cara);
            deplace += 1;
        }

    }

    public void dep()
    {
        Random rnd = new Random();
        float nx = rnd.Next(deplace);
        float ny = this.deplace - nx;
        if (rnd.Next(2) == 1)
            nx = -nx;
        if (rnd.Next(2) == 1)
            ny = -ny;
        if (validpos(X + nx, Y + ny))
        {
            Y += ny;
            X += nx;
            transform.position = new Vector3(X, Y, 0);
        }
        else
            dep();
    }

    public void update(game jeu)
    {
        Caracters cibles = cible(jeu);
        if (cibles == null)
            dep(jeu);
        else
            depto(jeu, cibles);
    }
    */
}
