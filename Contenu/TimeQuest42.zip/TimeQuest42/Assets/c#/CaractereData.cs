using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "cara", menuName = "MyGame/cara")]
public class CaractereData : ScriptableObject
{
    public int Vie;
    public int Prix;
    public int MeurtOr;
    public int MeurtBois;
    public int Force;
    public int Deplace;
}